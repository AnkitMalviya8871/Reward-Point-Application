package com.example.Reward.Point.Application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RewardPointApplicationTests {

	@Test
	void contextLoads() {
	}

}
